﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using WebApplication1.Models;
using WebApplication1.Models.Db;

namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly MyContext _myContext;

        public HomeController(ILogger<HomeController> logger, MyContext myContext)
        {
            _logger = logger;
            _myContext = myContext;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public IActionResult GetData([FromForm] RequestModel requestModel)
        {
            int year = 2000;
            if (requestModel.Date.Month == 1 && requestModel.Date.Day <= 20)
                year = 2001;
            
            var constellationTime = new DateTime(year, requestModel.Date.Month, requestModel.Date.Day);
            var zodiacSignKey = requestModel.Date.Year % 12;

            var constellation = _myContext.Constellation.FirstOrDefault(c =>
                c.StartTime <= constellationTime && c.EndTime >= constellationTime);

            var zodiacSign = _myContext.ZodiacSign.FirstOrDefault(c => c.Key == zodiacSignKey);

            var model = $"你的星座是 {constellation?.Name} 生肖屬 {zodiacSign?.Name}";

            return View("Index", model);
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}