﻿using System;

namespace WebApplication1.Models
{
    public class RequestModel
    {
        public DateTime Date { get; set; }
    }
}